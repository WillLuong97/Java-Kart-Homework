package asg5;

public enum AccountType {
	CHECKING, SAVINGS, MONEY_MARKET
}
