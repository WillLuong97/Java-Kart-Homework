package asg5;

public enum BusinessType {
	PERSONAL, CORPORATE, LLC
}
